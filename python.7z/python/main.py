# def func(a1,a2):
#     return a1,a2



# def max_digit(a,b):
#     return a if a>=b else b


# def fuct(n,fprint):
#     output=1
#     for i in range(1,n+1):
#         output*=i
#     return output, fprint


# glob = "jacpot"
# def fprint(loc):
#     loc = 'local'
    # print(loc, glob)

# def fib(num):
#     if num == 1:
#         return 1
#     elif num == 0: 
#         return 0
#     elif num>1:
#         return fib(num-1)+fib(num-2)
# print(fib(10))

# def distance(x1,y1,x2,y2):
#     return ((x2-x1)**2+(y2-y1)**2)**0.5

# print(distance(3,2,5,1))

# def power(a,n):
#     return a**n 


# def fibonach(n:int) ->int:
#     if n == 1:
#         return 1
#     elif n == 0:
#         return 0
#     elif n>1:
#         return fibonach(n-1)+fibonach(n-2)
    
# print(fibonach(6))

# def uniter(**kwargs):
#     return kwargs

# print(uniter(value='sdfads', cnt=2))

# def double(num:int) ->int:
#     return num*2
# res = double(10)
# print(res)

# func = double
# print(func(10))

# f = lambda x: x*x
# print(f(10))
# print([f(i) for i in range(1,11)])

# summa = lambda a = 0,b = 0: a+b

# print(summa())

# result = lambda x, y: x + y
# for i in range(1, 10):
#     for j in range(5,6):
#         print(result(i, j))

# def is_year(num):
#     return True if num % 4 == 0 and num % 400 !=0 else False
# print(is_year(400))

def square(x):
    s = ((x**2)*2)**0.5
    return x*4,x*x,s


def season(mounth):
    dict_mounth = {1:'январь',
     2:'февраль',
     3:'март',
     4:'апрель',
     5:'май',
     6:'июнь',
     7:'июль',
     8:'август',
     9:'сентябрь',
     10:'октябрь',
     11:'ноябрь',
     12:'декабрь'}
    
    return dict_mounth[mounth]

def bank(a: int,years:int) -> int:
    contribution = a
    for i in range(years):
        money_year = contribution*0.1
        contribution+=money_year
    return money_year
def is_prime(num):
    if num == 0:
        return False
    else:
        for i in range(2,int(num**0.5)+1):
            if num%i == 0:
                return False
            else:
                return True
def date(day,mounth,year):
    february_day = 28
    
    if year %4 !=0:
        february_day = 29
    elif year%100==0 and year % 400==0:
        february_day = 29
    dict_year = {1: 31,
     2:february_day,
     3:31,
     4:30,
     5:31,
     6:30,
     7:31,
     8:31,
     9:30,
     10:31,
     11:30,
     12:31}
    return True if dict_year[mounth] >= day else False
print(is_prime(42))
        

def counter(mass:list):
    mass.sort()
    ddict = {}
    cnt = 0
    for i in range(len(mass)-1):
        if mass[i] == mass[i+1]:
            cnt+=1
        elif mass[i] != mass[i+1]:
            cnt+=1
            ddict[mass[i]] = cnt
            cnt=0
    if mass[-1] == mass[-2]:
        ddict[mass[-1]]+=1
    else:
        ddict[mass[-1]] = 1
    return ddict
print(counter([1,1,3,2,1,3,4]))
