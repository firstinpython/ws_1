import random
mass_x = []
mass_0 = []
# def board() -> list:
#     return [" " for el in range(9)]

board = [" " for el in range(9)]
def display(board) ->None:
    print(f"{board[0]} | {board[1]}| {board[2]}")
    print("--|---|--")
    print(f"{board[3]} | {board[4]}| {board[5]}")
    print("--|---|--")
    print(f"{board[6]} | {board[7]}| {board[8]}")
    print("--|---|--")


def player_move(board):
    users_cell = []
    cell = int(input("(1, 9): "))-1
    if cell>9 or cell<0:
        print("Введите значения заново")
        cell = int(input("(1, 9): "))-1
    while True:
        if board[cell] == " ":
            board[cell] = "X"
            mass_x.append(cell)
            break
        else:
            print("вы ввели не корректные данные")
            cell = int(input())-1
    print(winner())
    if winner():
        quit()

def computer_move(board):
    while True:
        cell = random.randint(1,8)
        if board[cell] == " ":
            board[cell] = "0"
            mass_0.append(cell)
            break
        else:
            continue
    print(winner()
          )
    if winner():
        quit()
def winner():
    print(mass_x)
    print(mass_0)
    if ((0 and 1 and 2) in mass_x) or ((0 and 3 and 6) in mass_x) or ((0 and 4 and 7) in mass_x) or ((2 and 4 and 5) in mass_x) or  ((1 and 4 and 6) in mass_x) or ((3 and 4 and 5) in mass_x) or ((6 and 7 and 8) in mass_x) or ((2 and 5 and 8) in mass_x):
        print("X")
        return True
    elif (0 and 1 and 2) in mass_0 or (0 and 3 and 6) in mass_0 or (0 and 4 and 7) in mass_0 or (2 and 4 and 5) in mass_0 or  (1 and 4 and 6) in mass_0 or (3 and 4 and 5) in mass_0 or (6 and 7 and 8) in mass_0 or (2 and 5 and 8) in mass_0:
        print("0")
        return True
while True:
    display(board)
    player_move(board)
    computer_move(board)
